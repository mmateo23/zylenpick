import type { Metadata } from "next";

import { getHomeShowcase } from "@/features/venues/services/venues-service";
import type { HomeShowcaseItem } from "@/features/venues/types";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { ServiceShowcaseDishesTemplate } from "@/templates/service-showcase/service-showcase-dishes-template";

export const revalidate = 900;

export const metadata: Metadata = {
  title: "Demo Platos | ZylenPick",
  description: "Ruta de demo para explorar un carrusel visual de platos.",
  robots: {
    index: false,
    follow: false,
  },
};

function dedupeItems(items: HomeShowcaseItem[]) {
  const seen = new Set<string>();

  return items.filter((item) => {
    if (seen.has(item.id) || !item.imageUrl) {
      return false;
    }

    seen.add(item.id);
    return true;
  });
}

export default async function DemoDishesPage() {
  const showcase = isSupabaseConfigured()
    ? await getHomeShowcase()
    : { featuredItems: [], latestItems: [] };

  const items = dedupeItems([
    ...showcase.featuredItems,
    ...showcase.latestItems,
    ...showcase.featuredItems,
  ]);

  return <ServiceShowcaseDishesTemplate items={items} />;
}
