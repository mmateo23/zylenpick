"use client";

import { useMemo, useState } from "react";

import { CloseIcon } from "@/components/icons/close-icon";
import { FeaturedBadgeIcon } from "@/components/icons/featured-badge-icon";
import { BorderBeam } from "@/components/magicui/border-beam";
import { AddToCartButton } from "@/features/cart/components/add-to-cart-button";
import type { CartVenue } from "@/features/cart/types";
import { getMenuItemSecondaryImage } from "@/features/venues/menu-item-media";
import type { VenueMenuItem } from "@/features/venues/types";
import { formatPrice } from "@/lib/utils/currency";

type MenuItemGalleryCardProps = {
  item: VenueMenuItem;
  venue: CartVenue;
  anchorId?: string;
};

export function MenuItemGalleryCard({
  item,
  venue,
  anchorId,
}: MenuItemGalleryCardProps) {
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const images = useMemo(() => {
    const gallery = [
      item.imageUrl,
      item.secondaryImageUrl ?? getMenuItemSecondaryImage(item.name),
    ].filter(Boolean) as string[];

    return Array.from(new Set(gallery));
  }, [item.imageUrl, item.name, item.secondaryImageUrl]);

  const primaryImage = images[0] ?? null;
  const selectedImage = images[selectedImageIndex] ?? primaryImage;

  const handleOpenViewer = () => {
    setSelectedImageIndex(0);
    setIsViewerOpen(true);
  };

  const highlightClassName = item.isPickupMonthHighlight
    ? "border-[rgba(31,138,112,0.5)] shadow-[0_0_0_1px_rgba(31,138,112,0.24),0_18px_44px_rgba(31,138,112,0.18)] transition-[box-shadow,border-color,transform] duration-300 group-hover:border-[rgba(31,138,112,0.78)] group-hover:shadow-[0_0_0_1px_rgba(31,138,112,0.32),0_0_32px_rgba(31,138,112,0.24),0_22px_56px_rgba(31,138,112,0.28)]"
    : item.isFeatured
      ? "gold-spotlight-card border-[rgba(214,166,72,0.48)] shadow-[0_0_0_1px_rgba(214,166,72,0.22),0_18px_44px_rgba(214,166,72,0.16)] transition-[box-shadow,border-color,transform] duration-300 group-hover:border-[rgba(214,166,72,0.74)] group-hover:shadow-[0_0_0_1px_rgba(214,166,72,0.3),0_0_28px_rgba(214,166,72,0.2),0_22px_56px_rgba(214,166,72,0.24)]"
      : "border-[color:var(--border)] shadow-[var(--soft-shadow)] transition-[box-shadow,border-color,transform] duration-300";

  return (
    <>
      <article
        id={anchorId}
        className={`editorial-card hover-lift-card scroll-mt-28 overflow-hidden rounded-[2.4rem] border bg-[color:var(--surface)] ${highlightClassName}`}
      >
        {item.isFeatured ? (
          <BorderBeam
            size={300}
            duration={7}
            borderWidth={2}
            className="from-transparent via-[#f3d58d] to-transparent opacity-95"
          />
        ) : null}
        <button
          type="button"
          onClick={handleOpenViewer}
          className="gold-spotlight-content block w-full text-left"
          aria-label={`Ver ${item.name}`}
        >
          <div className="relative min-h-[22rem] overflow-hidden">
            <div
              className="min-h-[22rem] bg-cover bg-center transition duration-500 hover:scale-[1.02]"
              style={{
                backgroundImage: primaryImage
                  ? `linear-gradient(180deg, rgba(10, 12, 11, 0.12), rgba(10, 12, 11, 0.42)), url(${primaryImage})`
                  : "linear-gradient(180deg, rgba(31, 138, 112, 0.32), rgba(15, 22, 20, 0.46))",
              }}
            />
            {item.isFeatured ? (
              <>
                <div className="pointer-events-none absolute inset-0 rounded-t-[2.4rem] ring-1 ring-inset ring-[rgba(214,166,72,0.34)] transition duration-300 group-hover:ring-[rgba(214,166,72,0.58)]" />
                <div className="pointer-events-none absolute -left-8 top-8 h-20 w-20 rounded-full bg-[rgba(214,166,72,0.18)] opacity-70 blur-2xl transition duration-300 group-hover:opacity-100 group-hover:blur-3xl" />
              </>
            ) : null}
            {item.isPickupMonthHighlight ? (
              <>
                <div className="pointer-events-none absolute inset-0 rounded-t-[2.4rem] ring-1 ring-inset ring-[rgba(31,138,112,0.34)] transition duration-300 group-hover:ring-[rgba(31,138,112,0.62)]" />
                <div className="pointer-events-none absolute -right-10 top-8 h-24 w-24 rounded-full bg-[rgba(31,138,112,0.18)] blur-2xl transition duration-300 group-hover:bg-[rgba(31,138,112,0.26)] group-hover:blur-3xl" />
              </>
            ) : null}
          </div>
        </button>

        <div className="gold-spotlight-content p-7">
          <div className="mb-4 flex flex-wrap gap-2">
            {item.isFeatured ? (
              <span
                title="Destacado"
                aria-label="Destacado"
                className="featured-badge-animated inline-flex h-11 w-11 items-center justify-center rounded-full border border-[rgba(214,166,72,0.38)] bg-[rgba(214,166,72,0.12)] text-[#d6a648]"
              >
                <FeaturedBadgeIcon size={20} />
              </span>
            ) : null}
            {item.isPickupMonthHighlight ? (
              <span className="inline-flex rounded-full border border-[rgba(31,138,112,0.34)] bg-[rgba(31,138,112,0.14)] px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
                MÃ¡s recogido del mes
              </span>
            ) : null}
          </div>

          <div className="flex items-start justify-between gap-4">
            <h3 className="text-4xl font-semibold leading-[0.98] text-[color:var(--foreground)]">
              {item.name}
            </h3>
            <span className="whitespace-nowrap rounded-full bg-[color:var(--surface-strong)] px-3.5 py-2.5 text-sm font-semibold text-[color:var(--foreground)] shadow-[var(--card-shadow)]">
              {formatPrice(item.priceAmount, item.currency)}
            </span>
          </div>

          <p className="mt-5 text-sm leading-7 text-[color:var(--muted-strong)]">
            {item.description}
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <button
              type="button"
              onClick={handleOpenViewer}
              className="magnetic-button inline-flex items-center rounded-full border border-[color:var(--border)] bg-[color:var(--surface-strong)] px-4 py-2.5 text-sm font-semibold text-[color:var(--foreground)]"
            >
              Ver plato
            </button>

            <AddToCartButton
              venue={venue}
              item={{
                id: item.id,
                name: item.name,
                description: item.description,
                priceAmount: item.priceAmount,
                currency: item.currency,
                imageUrl: item.imageUrl,
              }}
              className="mt-0"
            />
          </div>
        </div>
      </article>

      {isViewerOpen ? (
        <div className="fixed inset-0 z-50 bg-[rgba(4,8,7,0.84)] backdrop-blur-sm">
          <div className="flex h-full min-h-0 flex-col p-3 sm:p-6">
            <div className="glass-panel mx-auto flex w-full max-w-6xl items-center justify-between rounded-[1.6rem] border border-white/10 px-4 py-3 text-white sm:px-5">
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.22em] text-white/54">
                  Plato
                </p>
                <h3 className="mt-1 text-xl font-semibold sm:text-2xl">
                  {item.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsViewerOpen(false)}
                className="magnetic-button inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white"
                aria-label="Cerrar visor"
              >
                <CloseIcon size={18} />
              </button>
            </div>

            <div className="mx-auto mt-3 grid min-h-0 w-full max-w-6xl flex-1 gap-3 lg:grid-cols-[minmax(0,1.2fr)_24rem]">
              <section className="glass-panel min-h-[45vh] overflow-hidden rounded-[2rem] border border-white/10 shadow-[var(--shadow)]">
                <div
                  className="h-full min-h-[45vh] bg-cover bg-center"
                  style={{
                    backgroundImage: selectedImage
                      ? `linear-gradient(180deg, rgba(10, 12, 11, 0.04), rgba(10, 12, 11, 0.2)), url(${selectedImage})`
                      : "linear-gradient(180deg, rgba(31, 138, 112, 0.32), rgba(15, 22, 20, 0.46))",
                  }}
                />
              </section>

              <aside className="glass-panel overflow-y-auto rounded-[2rem] border border-white/10 p-6 shadow-[var(--soft-shadow)]">
                <p className="text-sm uppercase tracking-[0.2em] text-[color:var(--brand)]">
                  Vista del plato
                </p>
                <h4 className="mt-4 text-4xl font-semibold leading-[0.96] text-[color:var(--foreground)]">
                  {item.name}
                </h4>
                <p className="mt-4 text-base leading-8 text-[color:var(--muted-strong)]">
                  {item.description}
                </p>
                <p className="mt-6 text-2xl font-semibold text-[color:var(--foreground)]">
                  {formatPrice(item.priceAmount, item.currency)}
                </p>

                {images.length > 1 ? (
                  <div className="mt-6 flex gap-3 overflow-x-auto pb-1">
                    {images.map((image, index) => {
                      const isActive = index === selectedImageIndex;

                      return (
                        <button
                          key={`${item.id}-${index}`}
                          type="button"
                          onClick={() => setSelectedImageIndex(index)}
                          className={`h-20 w-20 shrink-0 overflow-hidden rounded-[1.2rem] border transition ${
                            isActive
                              ? "border-[color:var(--brand)] shadow-[var(--card-shadow)]"
                              : "border-white/10"
                          }`}
                          aria-label={`Ver imagen ${index + 1} de ${item.name}`}
                        >
                          <span
                            className="block h-full w-full bg-cover bg-center"
                            style={{ backgroundImage: `url(${image})` }}
                          />
                        </button>
                      );
                    })}
                  </div>
                ) : null}

                <div className="mt-8">
                  <AddToCartButton
                    venue={venue}
                    item={{
                      id: item.id,
                      name: item.name,
                      description: item.description,
                      priceAmount: item.priceAmount,
                      currency: item.currency,
                      imageUrl: item.imageUrl,
                    }}
                    className="mt-0"
                  />
                </div>
              </aside>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
