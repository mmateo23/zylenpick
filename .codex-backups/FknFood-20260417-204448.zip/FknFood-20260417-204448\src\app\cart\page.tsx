import type { Metadata } from "next";
import { SiteShell } from "@/components/layout/site-shell";
import { CartScreen } from "@/features/cart/components/cart-screen";
import { getNoIndexMetadata } from "@/lib/seo";

export const metadata: Metadata = getNoIndexMetadata({
  title: "Cart",
  description: "Área privada del carrito de compra.",
});

export default function CartPage() {
  return (
    <SiteShell>
      <CartScreen />
    </SiteShell>
  );
}
