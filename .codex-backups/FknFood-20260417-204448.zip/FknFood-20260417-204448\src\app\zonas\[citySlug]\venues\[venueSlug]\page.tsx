import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

import { ClockIcon } from "@/components/icons/clock-icon";
import { LocationPinIcon } from "@/components/icons/location-pin-icon";
import { MapIcon } from "@/components/icons/map-icon";
import { PhoneIcon } from "@/components/icons/phone-icon";
import { WalkIcon } from "@/components/icons/walk-icon";
import { SiteShell } from "@/components/layout/site-shell";
import { CityPreferenceSync } from "@/components/location/city-preference-sync";
import { MenuItemGalleryCard } from "@/components/venues/menu-item-gallery-card";
import { VenueArrivalCard } from "@/components/venues/venue-arrival-card";
import { VenueOpeningHours } from "@/components/venues/venue-opening-hours";
import { VerifiedVenueBadge } from "@/components/venues/verified-venue-badge";
import { VenueCartSummary } from "@/features/cart/components/venue-cart-summary";
import { getVenueDetails } from "@/features/venues/services/venues-service";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getBaseMetadata } from "@/lib/seo";

export const revalidate = 1800;

type VenuePageProps = {
  params: {
    citySlug: string;
    venueSlug: string;
  };
};

export async function generateMetadata({
  params,
}: VenuePageProps): Promise<Metadata> {
  const venue = await getVenueDetails(params.citySlug, params.venueSlug);

  if (!venue) {
    return getBaseMetadata({
      title: "Local de comida local",
      description:
        "Consulta información del local, tiempos de recogida y platos disponibles.",
      path: `/zonas/${params.citySlug}/venues/${params.venueSlug}`,
    });
  }

  return getBaseMetadata({
    title: `${venue.name} en ${venue.city.name}`,
    description: `${venue.name} en ${venue.city.name}. Consulta carta, tiempos de recogida, dirección y platos disponibles para pedir localmente.`,
    path: `/zonas/${venue.city.slug}/venues/${venue.slug}`,
    image: venue.coverUrl ?? venue.logoUrl ?? "/logo/ZylenPick_LOGO.png?v=1",
  });
}

export default async function VenuePage({ params }: VenuePageProps) {
  if (!isSupabaseConfigured()) {
    return (
      <SiteShell>
        <section className="rounded-[2rem] border border-dashed border-[color:var(--border)] bg-[color:var(--surface)] p-8 shadow-[var(--soft-shadow)]">
          <p className="text-lg font-semibold text-[color:var(--foreground)]">
            Supabase no está configurado.
          </p>
          <p className="mt-3 text-sm leading-6 text-[color:var(--muted)]">
            Esta ruta necesita acceso a Supabase para mostrar el local y su menú.
          </p>
        </section>
      </SiteShell>
    );
  }

  const venue = await getVenueDetails(params.citySlug, params.venueSlug);

  if (!venue) {
    notFound();
  }

  const groupedItems = venue.menuItems.reduce<Record<string, typeof venue.menuItems>>(
    (accumulator, item) => {
      const key = item.categoryName ?? "Menú";
      accumulator[key] ??= [];
      accumulator[key].push(item);
      return accumulator;
    },
    {},
  );

  const cartVenue = {
    id: venue.id,
    slug: venue.slug,
    name: venue.name,
    citySlug: venue.city.slug,
    cityName: venue.city.name,
    address: venue.address,
    email: venue.email,
    phone: venue.phone,
    pickupEtaMin: venue.pickupEtaMin,
  };

  return (
    <SiteShell>
      <CityPreferenceSync city={{ slug: venue.city.slug, name: venue.city.name }} />

      <section
        className="editorial-card overflow-hidden rounded-[2.8rem] border border-white/28 px-8 py-10 text-white shadow-[var(--shadow)] sm:px-10 sm:py-12"
        style={{
          backgroundImage: venue.coverUrl
            ? `linear-gradient(180deg, rgba(18, 12, 10, 0.38), rgba(18, 12, 10, 0.86)), url(${venue.coverUrl})`
            : "linear-gradient(135deg, rgba(31, 138, 112, 0.48), rgba(15, 22, 20, 0.6))",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <Link
          href={`/zonas/${venue.city.slug}`}
          className="magnetic-button inline-flex w-fit rounded-full border border-white/16 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur"
        >
          Volver a {venue.city.name}
        </Link>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <span className="rounded-full border border-white/16 bg-white/10 px-4 py-2 text-xs font-medium uppercase tracking-[0.24em] text-white/76 backdrop-blur">
            {venue.city.name}
          </span>
          <span
            className={`inline-flex rounded-full border border-white/16 px-4 py-2 text-xs font-medium backdrop-blur ${
              venue.isOpenNow
                ? "bg-[color:var(--brand)]/16 text-white"
                : "bg-[#E5484D]/14 text-white"
            }`}
          >
            {venue.isOpenNow ? "Abierto ahora" : "Cerrado ahora"}
          </span>
        </div>

        <div className="mt-8 grid gap-8 xl:grid-cols-[minmax(0,1fr)_21rem]">
          <div>
            <div className="flex flex-wrap items-center gap-4">
              <h1 className="max-w-[10ch] text-balance text-5xl font-semibold leading-[0.9] sm:text-6xl lg:text-7xl">
                {venue.name}
              </h1>
              <VerifiedVenueBadge
                isVerified={venue.isVerified}
                subscriptionActive={venue.subscriptionActive}
                withLabel
              />
            </div>

            <p className="mt-6 max-w-[58ch] text-lg leading-8 text-white/82">
              {venue.description}
            </p>
          </div>

          <div className="rounded-[2.2rem] border border-white/16 bg-white/10 p-6 text-white backdrop-blur">
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-white/62">
              Recogida
            </p>
            <p className="mt-4 inline-flex items-center gap-3 text-4xl font-semibold">
              <WalkIcon size={24} className="text-[color:var(--accent)]" />
              {venue.pickupEtaMin ? `${venue.pickupEtaMin} min` : "Disponible"}
            </p>
            <p className="mt-4 text-sm leading-7 text-white/76">
              Un local preparado para decidir rápido, guardar platos y pasar a recoger
              sin complicaciones.
            </p>
          </div>
        </div>
      </section>

      <section className="mt-12 grid gap-8 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <div className="space-y-10">
          {Object.entries(groupedItems).map(([categoryName, items]) => (
            <section key={categoryName}>
              <div className="mb-6">
                <p className="text-xs font-medium uppercase tracking-[0.26em] text-[color:var(--brand)]">
                  Carta
                </p>
                <h2 className="mt-3 text-4xl font-semibold text-[color:var(--foreground)]">
                  {categoryName}
                </h2>
              </div>

              <div className="grid gap-7 lg:grid-cols-2">
                {items.map((item) => (
                  <MenuItemGalleryCard
                    key={item.id}
                    item={item}
                    venue={cartVenue}
                    anchorId={`plato-${item.id}`}
                  />
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="space-y-6">
          <VenueCartSummary venueId={venue.id} />
          <VenueArrivalCard
            venueSlug={venue.slug}
            venueName={venue.name}
            address={venue.address}
          />
          <VenueOpeningHours
            openingHours={venue.openingHours}
            isOpenNow={venue.isOpenNow}
          />

          <aside className="glass-panel rounded-[2.3rem] border border-[color:var(--border)] p-6 shadow-[var(--soft-shadow)]">
            <p className="text-xs font-medium uppercase tracking-[0.26em] text-[color:var(--brand)]">
              Información del local
            </p>
            <dl className="mt-6 space-y-6">
              <div>
                <dt className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-[color:var(--muted)]">
                  <MapIcon size={18} className="text-[color:var(--brand)]" />
                  Dirección
                </dt>
                <dd className="mt-2 text-sm leading-7 text-[color:var(--foreground)]">
                  {venue.address ?? "Dirección pendiente"}
                </dd>
              </div>
              <div>
                <dt className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-[color:var(--muted)]">
                  <ClockIcon size={18} className="text-[color:var(--brand)]" />
                  Recogida
                </dt>
                <dd className="mt-2 text-sm leading-7 text-[color:var(--foreground)]">
                  {venue.pickupNotes ?? "Indicaciones pendientes"}
                </dd>
              </div>
              <div>
                <dt className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-[color:var(--muted)]">
                  <PhoneIcon size={18} className="text-[color:var(--brand)]" />
                  Teléfono
                </dt>
                <dd className="mt-2 text-sm leading-7 text-[color:var(--foreground)]">
                  {venue.phone ?? "Teléfono pendiente"}
                </dd>
              </div>
              <div>
                <dt className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-[color:var(--muted)]">
                  <PhoneIcon size={18} className="text-[color:var(--brand)]" />
                  Correo
                </dt>
                <dd className="mt-2 text-sm leading-7 text-[color:var(--foreground)]">
                  {venue.email ?? "Correo pendiente"}
                </dd>
              </div>
              <div>
                <dt className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-[color:var(--muted)]">
                  <LocationPinIcon
                    size={18}
                    className="text-[color:var(--brand)]"
                  />
                  Zona
                </dt>
                <dd className="mt-2 text-sm leading-7 text-[color:var(--foreground)]">
                  {venue.city.name}
                </dd>
              </div>
            </dl>
          </aside>
        </div>
      </section>
    </SiteShell>
  );
}
